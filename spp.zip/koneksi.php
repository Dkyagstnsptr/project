<?php
$conn = mysqli_connect('localhost','root','','spp');

if(!$conn){
    echo "GAGAL";
}
?>